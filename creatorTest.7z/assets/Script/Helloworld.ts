const {ccclass, property} = cc._decorator;

@ccclass
export default class Helloworld extends cc.Component {

    @property(cc.Label)
    label: cc.Label = null;

    @property
    text: string = 'hello';

    @property(cc.SpriteFrame)
    sprFrame: cc.SpriteFrame = null;

    start () {
        // init logic
        // this.label.string = this.text;

        // cc.log("this.sprFrame.getTexture().url", this.sprFrame.getTexture().nativeUrl);

        // cc.resources.load("BatchSprMaterial", cc.Material, function(err, asserts : cc.Material) {
        //     let texture0 = asserts.getProperty("texture0", 0);
        //     cc.log("texture0", texture0);
        // })
    }
}
